Файлы конфигурации logstash
